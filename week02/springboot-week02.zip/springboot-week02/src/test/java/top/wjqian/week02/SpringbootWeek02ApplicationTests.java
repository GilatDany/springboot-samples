package top.wjqian.week02;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWeek02ApplicationTests {

    @Test
    void contextLoads() {
    }

}
