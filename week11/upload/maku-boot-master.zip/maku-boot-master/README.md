## 项目说明

- maku-boot 是采用SpringBoot4.0、SpringSecurity7.0、Mybatis-Plus、Vue3、Element-plus等技术开发的低代码开发平台，旨在为开发者提供一个简洁、高效、可扩展的低代码开发平台。
- 使用门槛极低，支持国密加密、达梦、人大金仓、华为高斯数据库等，符合信创需求的低代码开发平台。
- 采用组件模式，扩展不同的业务功能，可以很方便的实现各种业务需求，且不会导致系统臃肿，若想使用某个组件，按需引入即可，反之亦然。
- 支持Online在线表单开发，通过拖拽组件，实现表单开发，可快速开发业务，无需部署及重启服务等优点。
- 支持SSO单点登录功能，可解决企业内部单点问题，不受开发语言限制。
- 支持代码生成功能，可以生成单表、树表、多表等业务代码，开发更快速。
- 支持多种数据库，包括MySQL、SQL Server、Oracle、PostgreSQL、达梦、人大金仓、OpenGauss等，可灵活切换。
- 支持Flowable8工作流，包括流程设计、动态表单、多表单、或签、会签（票签）、依次审批、加签、、退回、转办、委托、抄送、撤销、子流程等。
- 支持多种登录方式，包括账号密码、短信验证码、企业微信、钉钉、飞书、微信等，可灵活选择。
- 支持多租户模式，可实现不同业务系统之间的隔离，能同时支持字段隔离、数据源隔离方式，满足对多租户的全部需求。

- 开发文档：https://maku.net/docs/maku-boot
- 演示环境：https://demo.maku.net
- 企业版：https://maku.net/price

## 移动端

我们提供了移动端版本，采用 Vue、Pinia、uni-app、uni-ui 框架开发，支持H5、微信小程序、Android、鸿蒙等。

- Android端，下载地址：https://app.maku.net/maku.apk
- H5版本，访问地址：https://app.maku.net
- 微信小程序，体验二维码：

![输入图片说明](images/wechat.jpg)


## 架构图

![输入图片说明](images/0.png)

## 效果图

<table>
    <tr>
        <td><img src="images/a1.jpg"/></td>
        <td><img src="images/a2.jpg"/></td>
    </tr>
    <tr>
        <td><img src="images/a3.jpg"/></td>
        <td><img src="images/a4.jpg"/></td>
    </tr>
    <tr>
        <td><img src="images/a5.jpg"/></td>
        <td><img src="images/a6.jpg"/></td>
    </tr>
    <tr>
        <td><img src="images/a7.jpg"/></td>
        <td><img src="images/a8.jpg"/></td>
    </tr>
    <tr>
        <td><img src="images/1.png"/></td>
        <td><img src="images/2.png"/></td>
    </tr>
    <tr>
        <td><img src="images/3.png"/></td>
        <td><img src="images/4.png"/></td>
    </tr>
    <tr>
        <td><img src="images/5.png"/></td>
        <td><img src="images/6.png"/></td>
    </tr>
    <tr>
        <td><img src="images/7.png"/></td>
        <td><img src="images/8.png"/></td>
    </tr>
    <tr>
        <td><img src="images/9.png"/></td>
        <td><img src="images/10.png"/></td>
    </tr>
    <tr>
        <td><img src="images/11.png"/></td>
        <td><img src="images/12.png"/></td>
    </tr>
    <tr>
        <td><img src="images/13.png"/></td>
        <td><img src="images/14.png"/></td>
    </tr>
    <tr>
        <td><img src="images/15.png"/></td>
        <td><img src="images/16.png"/></td>
    </tr>
    <tr>
        <td><img src="images/17.png"/></td>
        <td><img src="images/18.png"/></td>
    </tr>
    <tr>
        <td><img src="images/21.png"/></td>
        <td><img src="images/22.png"/></td>
    </tr>
    <tr>
        <td><img src="images/19.png"/></td>
        <td><img src="images/20.png"/></td>
    </tr>
</table>



## 版权说明
- MAKU生态技术框架全系列版本遵循Apache License 2.0开源协议。
- 允许教育培训、个人项目、承接私活及企业内部项目等使用，可享有终身免费许可。
- 禁止任何针对开源项目或产品销售的二次开发行为，未经授权的行为将视为侵权。
- 请尊重知识产权，不允许删除源码注释申明及作者信息，违者将追究法律责任。
